package com.colis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ColisService {

    @Autowired
    private ColisRepository colisRepository;

    public List<Colis> listAll(){
        return  colisRepository.findAll();
    }

    public void save(Colis c){
        colisRepository.save(c);

    }




    public Colis get(Long id){
        return colisRepository.findById(id).get();
    }

    public void delete(Long id){
        colisRepository.deleteById(id);
    }
}
