package com.colis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class ColisController {

    @Autowired
    private ColisService colisService;


    @RequestMapping("/suivre")
    public void showSaveColisPage(Model model) {
        List<Colis> listeColis= colisService.listAll();

        for (Colis c: listeColis){
            //System.out.println(c.getEmplacements().size());
        }
        //return "new_colis";
    }
    
    @RequestMapping("/")
    public String ViewHomePage(Model model){

        List<Colis> listeColis= colisService.listAll();
        model.addAttribute("listeColis", listeColis);
        return "index";
    }

    @RequestMapping("/new")
    public String showNewColisPage(Model model) {
        Colis colis = new Colis();
        model.addAttribute("colis", colis);

        return "new_colis";
    }

    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public String saveProduct(@ModelAttribute("colis") Colis colis) {

        String[] parts = colis.getEmplacements().split("//");
        String part1 = parts[0];
        String[] part = colis.getEtats().split("//");
        String part2 = part[0];
        String[] lati = colis.getLatitudes().split("//");
        String lat = lati[0];
        String[] longi = colis.getLongitudes().split("//");
        String lon = longi[0];
        if(colis.getId()!= null){
            if(part1.equals(colis.getEmplacement()) && part2.equals(colis.getEtat()) && lat.equals(Double.toString(colis.getLatitude())) && lon.equals(Double.toString(colis.getLongitude()))  ){

            }
            else{
                colis.setEmplacements(colis.getEmplacement()+"//"+colis.getEmplacements());
                colis.setEtats(colis.getEtat()+"//"+colis.getEtats());
                colis.setLatitudes(colis.getLatitude()+"//"+colis.getLatitudes());
                colis.setLongitudes(colis.getLongitude()+"//"+colis.getLongitudes());
            }


        }
        else{
            colis.setEmplacements(colis.getEmplacement());
            colis.setEtats(colis.getEtat());
            colis.setLatitudes(Double.toString(colis.getLatitude()));
            colis.setLongitudes(Double.toString(colis.getLongitude()));


        }







        colisService.save(colis);
       /* System.out.println("after");
        System.out.println(cc.getEmplacements());*/
        return "redirect:/";
    }

    @RequestMapping("/edit/{id}")
    public ModelAndView showEditProductPage(@PathVariable(name = "id") Long id) {
        ModelAndView mav = new ModelAndView("edit_colis");
        Colis colis = colisService.get(id);
        mav.addObject("colis", colis);

        return mav;
    }

    @RequestMapping("/suivre/{id}")
    public ModelAndView showSuivreColisPage(@PathVariable(name = "id") Long id) {
        ModelAndView mav = new ModelAndView("suivre_colis");
        Colis colis = colisService.get(id);
        mav.addObject("colis", colis);

        return mav;
    }

    @RequestMapping("/delete/{id}")
    public String deleteProduct(@PathVariable(name = "id") Long id) {
        colisService.delete(id);
        return "redirect:/";
    }
}

